package FlatManager;

public enum Furnish {
	DESIGNER,
	NONE,
	LITTLE;
}


