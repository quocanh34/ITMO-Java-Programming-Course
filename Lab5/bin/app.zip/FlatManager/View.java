package FlatManager;

public enum View {
	STREET,
	YARD,
	PARK,
	GOOD,
	TERRIBLE;
}



