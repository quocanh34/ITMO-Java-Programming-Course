package HostSystem;

import FlatManager.Flat;

import java.util.ArrayList;
import java.util.List;

public class Flats {

    private List<Flat> flats = null;

    public List<Flat> getFlats(){
        return flats;
    }

    public void setFlats(ArrayList<Flat> flats){
        this.flats = flats;
    }
}
